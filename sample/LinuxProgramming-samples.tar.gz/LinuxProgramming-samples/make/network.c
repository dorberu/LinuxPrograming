int
a(void)
{
    return 1;
}
