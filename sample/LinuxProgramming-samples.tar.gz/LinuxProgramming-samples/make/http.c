int
b(void)
{
    return 1;
}
