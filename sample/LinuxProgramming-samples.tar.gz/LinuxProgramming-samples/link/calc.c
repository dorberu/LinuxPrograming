#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int
main(int argc, char *argv[])
{
    printf("sin(0.5)=%g\n", sin(0.5));
    exit(0);
}
