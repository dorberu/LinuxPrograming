#include <stdio.h>
#include <stdlib.h>

int
main(int argc, char *argv[])
{
    int *p = NULL;

    printf("%d\n", *p);
    exit(0);
}
